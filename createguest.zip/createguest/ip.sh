#!/bin/bash

# Auto ip changer bash script

# -------------------------------
# 🎨 </> Developer : Kunal 
# -------------------------------


R='\e[1;31m'    # Red
G='\e[1;32m'    # Green
Y='\e[1;33m'    # Yellow
B='\e[1;34m'    # Blue
P='\e[1;35m'    # Purple
C='\e[1;36m'    # Cyan
W='\e[1;37m'    # White
LR='\e[0;31m'   # Light Red
NC='\e[0m'      # Reset

type_effect() {
    local text="$1"
    local delay="$2"

    for ((i=0; i<${#text}; i++)); do
        echo -ne "${text:$i:1}"
        sleep "$delay"
    done
    echo
}
clear
echo -e ""
echo -e ""
echo -e "${C}${R}    ██╗  ██╗██╗   ██╗███╗   ██╗ █████╗ ██╗     ${C}${NC}"
echo -e "${C}${R}    ██║ ██╔╝██║   ██║████╗  ██║██╔══██╗██║     ${C}${NC}"
echo -e "${C}${R}    █████╔╝ ██║   ██║██╔██╗ ██║███████║██║     ${C}${NC}"
echo -e "${C}${R}    ██╔═██╗ ██║   ██║██║╚██╗██║██╔══██║██║     ${C}${NC}"
echo -e "${C}${R}    ██║  ██╗╚██████╔╝██║ ╚████║██║  ██║███████╗${C}${NC}"
echo -e "${C}${R}    ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝${C}${NC}"

echo -e "${C}
          ┏─────────────────────────────────────────┓${NC}"
echo -e "${C}          ┃ ${G}DEV: @Kunal_Py ${W}⚡ ${Y}ULTRA FAST IP CHANGER ${C}┃${NC}"
echo -e "${C}          ┗─────────────────────────────────────────┛

${NC}"

# === STARTUP SEQUENCE ===

echo -e "${P}[+] ${W}INITIALIZING GHOST PROTOCOL...${NC}"
sleep 1
echo -e ""
echo -e ""
type_effect "🔐 Bypassing ISP Firewalls..." 0.02
type_effect "🎐 Establishing Secure Tunnel..." 0.02
echo -e ""

# === CHECK TOR ===

if ! command -v tor &> /dev/null; then
    echo -e "\n${R}┏━━━━━━━ [ ERROR: CORE MISSING ] ━━━━━━━┓${NC}"
    echo -e "${R}┃ ${W}TOR IS NOT INSTALLED ON THIS DEVICE!  ${R}┃${NC}"
    echo -e "${R}┃ ${Y}FIX: pkg install tor -y               ${R}┃${NC}"
    echo -e "${R}┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛${NC}"
    exit 1
fi

pkill -9 tor &>/dev/null
tor &>/dev/null &
sleep 5

echo -e "\n${G}✅ SYSTEM READY! ROTATION STARTED...${NC}"
echo -e ""

# === MAIN LOOP ===

while true; do
    echo -e "
    ${Y}🎭 Assigning New IP Address...${NC}"
echo -e ""
    pkill -HUP tor
    NEW_IP=$(torsocks curl -s https://checkip.amazonaws.com)

    if [[ -z "$NEW_IP" ]]; then
        echo -e "${R}╔════════════════════ ERROR DETECTED ══════════════════════╗${NC}"
        echo -e "${R}║${W}  [!] STATUS  : ${Y}SIGNAL LOST                           ${R}║${NC}"
        echo -e "${R}║${W}  [!] CAUSE   : ${C}NETWORK FAILED                          ${R}║${NC}"
        echo -e "${R}║${W}  [!] ACTION  : ${G}RE-INJECTING EXPLOIT...               ${R}║${NC}"
        echo -e "${R}╚══════════════════════════════════════════════════════════╝${NC}"
        sleep 2
    else
        echo -e "${B}┌────────────────────────────────────────────────┐${NC}"
        echo -e "${B}│ ${G} 🛡️  PROTECTION  ${W}: ${R}ACTIVE (ULTRA)               ${B}│${NC}"
        echo -e "${B}│ ${G} 🌐  NEW IP ADDR ${W}: ${Y}$NEW_IP                ${B}│${NC}"
        echo -e "${B}│ ${G} 👤  TELEGRAM   ${W}: ${C}@Kunal_Py                    ${B}│${NC}"
        echo -e "${B}│ ${G} ⏰  LOG TIME    ${W}: $(date +%H:%M:%S)                    ${B}│${NC}"
        echo -e "${B}└────────────────────────────────────────────────┘${NC}"
        echo -e ""
        echo -e "         ${P}✨ ${W}O W N E R :  ${R}K U N A L ${P} ✨${NC}"
        echo -e ""
        echo -e "\a"
    fi

    echo
    echo -ne "${W}[${R}♔${W}] NEXT JUMP IN PROGRESS: "
    for i in {1..7}; do echo -ne "${R}█"; sleep 0.1; done
    for i in {1..7}; do echo -ne "${Y}█"; sleep 0.1; done
    for i in {1..7}; do echo -ne "${G}█"; sleep 0.1; done
    for i in {1..7}; do echo -ne "${C}█"; sleep 0.1; done

    echo -e " ${G}      🎗️ DONE!${NC}\n"
done
